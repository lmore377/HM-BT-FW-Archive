Jnhuamao Technology Co,. Ltd.

www.jnhuamao.cn

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

CC2540 Bluetooth Low Energy USB Dongle Firmware
Release Notes

V605
Add long name support, max name string length is 21 Bytes.


V601
=======================================================================
V601 doesnt add new command or functions.
Just rebuild HCI layer.

                                         HMSoft
                                         2017.09
V535
=======================================================================
Modify AT+FFE2 command add parameters '2'
AT+FFE2<P1> to query or change if use two UUID.
P1: ?   --Query
P1: 0   --Only use one Characteristic.
P1: 1   --Use two Characteristic, Second Characteristic value = first Characteristic value + 1
P1: 2   --Use two Characteristic, Second Characteristic value = first Characteristic value - 1
First Characteristic could use AT+CHAR command to setup.

Modify AT+SHOW command, add parameter '2' and parameter '3'
AT+SHOW<P1> used to query or set if show device name or device RSSI value when execute a discovery proceudre
P1: ?  -- Query
P1: 0  -- Dont show name or RSSI value
P1: 1  -- Show name
P1: 2  -- Show RSSI value
P1: 3  -- Show name and RSSI value

RSSI value total length is 14 Bytes.
RSSI value format "OK+RSSI:<P1>\r\n"
                  <P1>s: 4 Bytes RSSI value

                                                HMSoft
                                                2017.7

Version 534
=======================================================================
Add AT+DISA? command used to search devices and return full information
Possible return string format:
OK+DISS  --> Search start
<OK+DISA:><Device Address><Device Type><Device RSSI><Rest data length><Rest data>
OK+DISE  --> Search end

                                                HMSoft
                                                2017.4

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
Version 534
2017-04-10
Notices:
  -Add AT+128B command used to switch 16 Bits or 128 Bits study function.
  -Please use HMConfigAssistant.exe to create AT commands list.
s

Add AT+128B<P1> command used to connect slave device who is using 128 bits UUID
P1: ?  ----- Query
P1: 0  ----- Doesnt use 128 Bits UUID, Default value.
P1: 1  ----- Use 128 Bit UUID
Please use HMConfigAssistant.exe to create AT Commands.

Version 533
2016-12-07
Notices:
  -Add AT+FFE2 command used to add a new Characteristic
  -Add AT+TYPE command used to control module security type

Add AT+FFE2<P1> command used to add a new Characteristic.
P1: ?  ----- Query
P1: 0  ----- Close FFE2 Characteristic, Default value.
P1: 1  ----- Open FFE2 Characteristic

if AT+FFE20 is setup
Service and Characteristic list as follow:
  Service FFE0
  Characteristic FFE1 (if AT+RESP0 was setup, Properties is Read, WriteWithoutResponse, Notify)
  Characteristic FFE1 (if AT+RESP1 was setup, Properties is Read, Write, Notify)
if AT+FFE21 is setup
Service and Characteristic list as follow:
  Service FFE0
  Characteristic FFE1 (Properties is Read, Notify)
  Characteristic FFE2 (if AT+RESP0 was setup, Properties is WriteWithoutResponse)
  Characteristic FFE2 (if AT+RESP1 was setup, Properties is Write)

AT+TYPE<P1> command is used to control module security type
  P1: ? ---- Query current value
  P1: 0 ---- Doesnt need any security value (default value)
  P1: 1 ---- Need a sample security (Display yes or no)
  P2: 2 ---- Need a pin code (000000 ~ 999999)



V532
2016-10-31
Changes and Enhancements:
Modify pari procedure
Perfect work with UWP


Version 531
2016-10-10
Notices:

- Add some AT commands.
- Change some workflow of discovery.
- Add study function
  
Changes and Enhancements:

1. Add AT+SCAN[P1] command, config scan time in master role
   P1 value: 1 ~ 9 (Unit second); Default: 3(3 Seconds);
   P1 value: ? for query current value


Version 530
2016-05-17
Notices:

- Add some AT commands.
- Change some workflow of discovery.
- Add study function
  
Changes and Enhancements:

1. Add AT+COMI command, config Minimum Link Layer connection interval
   para1 value: 0 ~ 9; Default: 3(20ms);
   0: 7.5ms; 1: 10ms; 2: 15ms; 3: 20ms; 4: 25ms; 5: 30ms; 6: 35ms; 7: 40ms; 8: 45ms; 9: 4000ms
2. Add AT+COMA command, config Maximum Link Layer connection interval
   para1 value: 0 ~ 9; Default: 7(40ms);
   0: 7.5ms; 1: 10ms; 2: 15ms; 3: 20ms; 4: 25ms; 5: 30ms; 6: 35ms; 7: 40ms; 8: 45ms; 9: 4000ms
3. Add AT+COLA command, config Link Layer connection slave latency
   para1 value: 0 ~ 4; Default: 0;
4. Add AT+COSU command, config Link Layer connection supervision timeout
   para1 value: 0 ~ 6; Default: 6(6000ms);
   0: 100ms; 1: 1000ms; 2: 2000ms; 3: 3000ms; 4: 4000ms; 5: 5000ms; 6: 6000ms;
5. Add AT+COUP command, switch slave role update connection parameter
   para1 value 0, 1; Default: 1(Update on);
   0: Update off; 1: Update on;
6. Add AT+COMP command, switch study function
   para1 value 0, 1; Default: 0(Close study function);
   0: Close study function; 1: Open study function;

Version 526
2015-04-28

Notices:

- Add some AT commands.
- Change some workflow of discovery.
  
Changes and Enhancements:

1. Add AT+GAIN command, setup RX gain
   para1 value: 0~1


Version V523
2014-09-01

Changes and Enhancements:

- Remove AT+FILT command.
- Add AT+ADVI command.
- Fixed change uuid bugs.



Version V522
2014-02-03

Changes and Enhancements:

- Add Enable notify function.
- Fixed change uuid bugs.


Version V520
2014-01-03

Changes and Enhancements:

- Add AT+IBE0 command (Query/Set iBeacon UUID).
- Add AT+IBE1 command (Query/Set iBeacon UUID).
- Add AT+IBE2 command (Query/Set iBeacon UUID).
- Add AT+IBE3 command (Query/Set iBeacon UUID).
- Remove AT+IB1 command (Query/Set iBeacon UUID).
- Remove AT+IB2 command (Query/Set iBeacon UUID).


Version V519
2013-12-20

Changes and Enhancements:

- Add AT+ADTY command (Query/Set Advertising type)
- Add AT+MEAS command (Query/Set Measrued power)
- Add AT+IB1 command (Query/Set iBeacon UUID 01)
- Add AT+IB2 command (Query/Set iBeacon UUID 02)


Version V515
2013-12-18

Changes and Enhancements:

- Add AT+SHOW command (open/close if send name information when discovery)

Version V513
2013-12-13

Notices:

- Fix some bugs.
- Add some AT commands.
- Change some workflow of discovery.
  
Changes and Enhancements:

- Add AT+IBEA command (Open close iBeacon)
- Add AT+MARJ command (Query/Set iBeacon marjor)
- Add AT+MINO command (Query/Set iBeacon minor)
- Add AT+MODE command (Query/Set Dongle work mode)
  ?: Query mode
  0: Trans mode
  1: Remote config + Trans mode

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

